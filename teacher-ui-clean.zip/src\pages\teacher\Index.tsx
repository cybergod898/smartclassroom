import React from 'react';

export default function Index() {
  return <div style={{padding: 20}}>教师首页（v0.9.0）</div>;
}