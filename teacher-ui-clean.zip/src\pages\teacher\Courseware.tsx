import React from 'react';

export default function Courseware(){return <div style={{padding:20}}>Courseware Page</div>;}