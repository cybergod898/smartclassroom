import React from 'react';

export default function Profile(){return <div style={{padding:20}}>Profile Page</div>;}